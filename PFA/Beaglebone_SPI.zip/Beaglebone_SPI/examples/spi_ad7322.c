/**
 * @file spi_AD7322.c
 * 
 * @brief AD7322 ADC.
 * 
 * Requires an SPI Kernel driver be loaded to expose a /dev/spidevX.Y 
 * interface and an AD7322 be connected on the SPI bus.
 */

#include "spidriver.h"
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <signal.h>

#define AD7322_BUS       1        // Connected to /dev/spidev1.X bus
#define AD7322_CS        0        // Using chip select 0 (/dev/spidev1.0)
#define AD7322_FREQ      1000000  // SPI clock frequency in Hz
#define AD7322_BITS      16       // SPI bits per word
#define AD7322_CLOCKMODE 2        // SPI clock mode

static uint8_t running;
uint16_t CH0=,CH1=,range=;

/**
 * @brief Sets the given SPI bus per the AD7322's required configuration
 *
 * @param spi_fd SPI bus file descriptor
 */
void AD7322_SPIConfig(int spi_fd)
 {
  SPI_setMaxFrequency(spi_fd, AD7322_FREQ);
  SPI_setBitsPerWord(spi_fd, AD7322_BITS);
  SPI_setClockMode(spi_fd, AD7322_CLOCKMODE);
  SPI_setCSActiveHigh(spi_fd);
  SPI_setBitOrder(spi_fd, SPI_LSBFIRST);
}
void AD7322_write(int spi_fd, uint16_t value)
 {
  SPI_write(spi_fd, (void*) &value, 1);
 }
void AD7322_Transfer(int spi_fd, uint16_t send, uint16_t recieve)
 {
  SPI_transfer (spi_fd, (void*) &send, (void*) &recieve, 1 );
 }

/**
 * @brief Called when Ctrl+C is pressed - triggers the program to stop.
 */
void stopHandler(int sig) { running = 0;}

int main()
{
  int spi_fd, ad=0;
  // Open the SPI device file:
  spi_fd = SPI_open(AD7322_BUS, AD7322_CS);
  if (spi_fd < 0) {printf("Can't open SPI bus %d\n", AD7322_BUS); exit(0);}
  // Configure the SPI bus:
  AD7322_SPIConfig(spi_fd);

  // Loop until Ctrl+C pressed:
  running = 1;
  
  AD7322_write((spi_fd,range);
  
  signal(SIGINT, stopHandler);
  while(running) 
	{
		
		 AD7322_Transfer (spi_fd, CH0, ad);
		 printf("Voltage = %d mV", (ad&0x1FFF)*375>>7); //res=ad*12000/4095 mV
      
    }
  }
  // close the SPI file descriptor:
 
  SPI_close(spi_fd);
  return 0;
}

