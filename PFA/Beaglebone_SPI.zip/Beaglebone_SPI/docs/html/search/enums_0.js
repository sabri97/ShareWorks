var searchData=
[
  ['spi_5fbit_5forder',['SPI_bit_order',['../spidriver_8h.html#a31bd35a1aecbf364e888c14b090ff3d4',1,'spidriver.h']]]
];
