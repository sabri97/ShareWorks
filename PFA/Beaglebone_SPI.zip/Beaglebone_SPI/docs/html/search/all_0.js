var searchData=
[
  ['ad7390_5fsetvalue',['AD7390_setValue',['../spi__ad7390_8c.html#ac81c90f47d77aab40f41db9d14b947f9',1,'spi_ad7390.c']]],
  ['ad7390_5fspiconfig',['AD7390_SPIConfig',['../spi__ad7390_8c.html#a2a512b31146b2cda1657e3201402b9ad',1,'spi_ad7390.c']]]
];
